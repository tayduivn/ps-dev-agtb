<?php
$module_name = 'Eric_b1';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'team_name',
            'label' => 'LBL_TEAMS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'checkboxfield',
            'label' => 'LBL_CHECKBOXFIELD',
          ),
          1 => 
          array (
            'name' => 'datefield',
            'label' => 'LBL_DATEFIELD',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'dropdownfield',
            'studio' => 'visible',
            'label' => 'LBL_DROPDOWNFIELD',
          ),
          1 => 
          array (
            'name' => 'relatefield',
            'studio' => 'visible',
            'label' => 'LBL_RELATEFIELD',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'eric_b1_eric_f1_name',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'eric_b1_accounts_1_name',
          ),
        ),
      ),
    ),
  ),
);
?>
