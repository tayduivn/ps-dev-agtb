<?php
$module_name = 'Eric_b1';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'checkboxfield',
            'label' => 'LBL_CHECKBOXFIELD',
          ),
          1 => 
          array (
            'name' => 'datefield',
            'label' => 'LBL_DATEFIELD',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'dropdownfield',
            'studio' => 'visible',
            'label' => 'LBL_DROPDOWNFIELD',
          ),
          1 => 
          array (
            'name' => 'relatefield',
            'studio' => 'visible',
            'label' => 'LBL_RELATEFIELD',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'team_name',
            'displayParams' => 
            array (
              'display' => true,
            ),
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'eric_b1_eric_f1_name',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'eric_b1_accounts_1_name',
          ),
        ),
      ),
    ),
  ),
);
?>
