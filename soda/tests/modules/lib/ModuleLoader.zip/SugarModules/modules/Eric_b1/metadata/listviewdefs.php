<?php
$module_name = 'Eric_b1';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'TEAM_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_TEAM',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'default' => true,
  ),
  'DROPDOWNFIELD' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_DROPDOWNFIELD',
    'width' => '10%',
  ),
  'RELATEFIELD' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_RELATEFIELD',
    'width' => '10%',
    'default' => true,
  ),
  'CHECKBOXFIELD' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_CHECKBOXFIELD',
    'width' => '10%',
    'default' => true,
  ),
  'DATEFIELD' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATEFIELD',
    'width' => '10%',
    'default' => true,
  ),
);
?>
