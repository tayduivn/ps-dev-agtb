<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2009 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
$mod_strings = array (
  'LBL_TEAM' => 'Team',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_MODULE_NAME' => 'f1_label',
  'LBL_MODULE_TITLE' => 'f1_label',
  'LNK_NEW_DOCUMENT' => 'Create Document',
  'LNK_DOCUMENT_LIST' => 'Documents List',
  'LBL_SEARCH_FORM_TITLE' => 'Search f1_label',
  'LBL_DOCUMENT_ID' => 'Document ID',
  'LBL_CATEGORY' => 'Category',
  'LBL_SUBCATEGORY' => 'Sub Category',
  'LBL_STATUS' => 'Status',
  'LBL_IS_TEMPLATE' => 'Is a Template',
  'LBL_TEMPLATE_TYPE' => 'Document Type',
  'LBL_REVISION_NAME' => 'Revision Number',
  'LBL_MIME' => 'Mime Type',
  'LBL_REVISION' => 'Revision',
  'LBL_DOCUMENT' => 'Related Document',
  'LBL_LATEST_REVISION' => 'Latest Revision',
  'LBL_CHANGE_LOG' => 'Change Log',
  'LBL_ACTIVE_DATE' => 'Publish Date',
  'LBL_EXPIRATION_DATE' => 'Expiration Date',
  'LBL_FILE_EXTENSION' => 'File Extension',
  'LBL_CAT_OR_SUBCAT_UNSPEC' => 'Unspecified',
  'LBL_NEW_FORM_TITLE' => 'New f1_label',
  'LBL_DOC_NAME' => 'Document Name:',
  'LBL_FILENAME' => 'File Name:',
  'LBL_DOC_VERSION' => 'Revision:',
  'LBL_CATEGORY_VALUE' => 'Category:',
  'LBL_SUBCATEGORY_VALUE' => 'Sub Category:',
  'LBL_DOC_STATUS' => 'Status:',
  'LBL_DET_TEMPLATE_TYPE' => 'Document Type:',
  'LBL_DOC_DESCRIPTION' => 'Description:',
  'LBL_DOC_ACTIVE_DATE' => 'Publish Date:',
  'LBL_DOC_EXP_DATE' => 'Expiration Date:',
  'LBL_LIST_FORM_TITLE' => 'f1_label List',
  'LBL_LIST_DOCUMENT' => 'Document',
  'LBL_LIST_CATEGORY' => 'Category',
  'LBL_LIST_SUBCATEGORY' => 'Sub Category',
  'LBL_LIST_REVISION' => 'Revision',
  'LBL_LIST_LAST_REV_CREATOR' => 'Published By',
  'LBL_LIST_LAST_REV_DATE' => 'Revision Date',
  'LBL_LIST_VIEW_DOCUMENT' => 'View',
  'LBL_LIST_DOWNLOAD' => 'Download',
  'LBL_LIST_ACTIVE_DATE' => 'Publish Date',
  'LBL_LIST_EXP_DATE' => 'Expiration Date',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_SF_DOCUMENT' => 'Document Name:',
  'LBL_SF_CATEGORY' => 'Category:',
  'LBL_SF_SUBCATEGORY' => 'Sub Category:',
  'LBL_SF_ACTIVE_DATE' => 'Publish Date:',
  'LBL_SF_EXP_DATE' => 'Expiration Date:',
  'DEF_CREATE_LOG' => 'Document Created',
  'ERR_DOC_NAME' => 'Document Name',
  'ERR_DOC_ACTIVE_DATE' => 'Publish Date',
  'ERR_DOC_EXP_DATE' => 'Expiration Date',
  'ERR_FILENAME' => 'File Name',
  'LBL_TREE_TITLE' => 'Documents',
  'LBL_LIST_DOCUMENT_NAME' => 'Document Name',
  'LBL_HOMEPAGE_TITLE' => 'My f1_label',
  'LNK_NEW_RECORD' => 'Create f1_label',
  'LNK_LIST' => 'f1_label',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_ERIC_F1_SUBPANEL_TITLE' => 'f1_label',
);
?>
