<?php
// created: 2009-09-21 01:43:26
$layout_defs["Eric_b1"]["subpanel_setup"]["eric_b1_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ERIC_B1_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'eric_b1_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
