<?php
// created: 2009-09-21 01:43:26
$dictionary["eric_b1_accounts"] = array (
  'true_relationship_type' => 'many-to-many',
  'relationships' => 
  array (
    'eric_b1_accounts' => 
    array (
      'lhs_module' => 'Eric_b1',
      'lhs_table' => 'eric_b1',
      'lhs_key' => 'id',
      'rhs_module' => 'Accounts',
      'rhs_table' => 'accounts',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'eric_b1_accounts_c',
      'join_key_lhs' => 'eric_b1_ac3deaeric_b1_ida',
      'join_key_rhs' => 'eric_b1_ac8220ccounts_idb',
    ),
  ),
  'table' => 'eric_b1_accounts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'eric_b1_ac3deaeric_b1_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'eric_b1_ac8220ccounts_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'eric_b1_accountsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'eric_b1_accounts_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'eric_b1_ac3deaeric_b1_ida',
        1 => 'eric_b1_ac8220ccounts_idb',
      ),
    ),
  ),
);
?>
