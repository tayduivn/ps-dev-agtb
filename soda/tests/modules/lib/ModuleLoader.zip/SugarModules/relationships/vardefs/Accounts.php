<?php
// created: 2009-09-21 01:43:26
$dictionary["Account"]["fields"]["eric_b1_accounts"] = array (
  'name' => 'eric_b1_accounts',
  'type' => 'link',
  'relationship' => 'eric_b1_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ACCOUNTS_FROM_ERIC_B1_TITLE',
);
?>
<?php
// created: 2009-09-21 01:43:27
$dictionary["Account"]["fields"]["eric_b1_accounts_1"] = array (
  'name' => 'eric_b1_accounts_1',
  'type' => 'link',
  'relationship' => 'eric_b1_accounts_1',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ACCOUNTS_1_FROM_ERIC_B1_TITLE',
);
?>
<?php
// created: 2009-09-21 01:43:27
$dictionary["Account"]["fields"]["eric_b1_accounts_1_name"] = array (
  'name' => 'eric_b1_accounts_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ACCOUNTS_1_FROM_ERIC_B1_TITLE',
  'save' => true,
  'id_name' => 'eric_b1_ac54aeeric_b1_ida',
  'link' => 'eric_b1_accounts_1',
  'table' => 'eric_b1',
  'module' => 'Eric_b1',
  'rname' => 'name',
);
?>
<?php
// created: 2009-09-21 01:43:27
$dictionary["Account"]["fields"]["eric_b1_ac54aeeric_b1_ida"] = array (
  'name' => 'eric_b1_ac54aeeric_b1_ida',
  'type' => 'link',
  'relationship' => 'eric_b1_accounts_1',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ACCOUNTS_1_FROM_ERIC_B1_TITLE',
);
?>
