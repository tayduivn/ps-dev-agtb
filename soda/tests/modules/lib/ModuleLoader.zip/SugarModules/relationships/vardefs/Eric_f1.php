<?php
// created: 2009-09-21 01:43:26
$dictionary["Eric_f1"]["fields"]["eric_b1_eric_f1"] = array (
  'name' => 'eric_b1_eric_f1',
  'type' => 'link',
  'relationship' => 'eric_b1_eric_f1',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ERIC_F1_FROM_ERIC_B1_TITLE',
);
?>
<?php
// created: 2009-09-21 01:43:26
$dictionary["Eric_f1"]["fields"]["eric_b1_eric_f1_name"] = array (
  'name' => 'eric_b1_eric_f1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ERIC_F1_FROM_ERIC_B1_TITLE',
  'save' => true,
  'id_name' => 'eric_b1_erae97eric_b1_ida',
  'link' => 'eric_b1_eric_f1',
  'table' => 'eric_b1',
  'module' => 'Eric_b1',
  'rname' => 'name',
);
?>
<?php
// created: 2009-09-21 01:43:26
$dictionary["Eric_f1"]["fields"]["eric_b1_erae97eric_b1_ida"] = array (
  'name' => 'eric_b1_erae97eric_b1_ida',
  'type' => 'link',
  'relationship' => 'eric_b1_eric_f1',
  'source' => 'non-db',
  'vname' => 'LBL_ERIC_B1_ERIC_F1_FROM_ERIC_B1_TITLE',
);
?>
