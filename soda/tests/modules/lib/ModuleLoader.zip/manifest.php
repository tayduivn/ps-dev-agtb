    <?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2009 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            
          ),
          'acceptable_sugar_flavors' =>
          array(
            'ENT'
          ),
          'readme'=>'',
          'key'=>'Eric',
          'author' => '',
          'description' => '',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'P_Eric',
          'published_date' => '2009-09-21 01:43:25',
          'type' => 'module',
          'version' => '1253497405',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'P_Eric',
  'beans' => 
  array (
    0 => 
    array (
      'module' => 'Eric_b1',
      'class' => 'Eric_b1',
      'path' => 'modules/Eric_b1/Eric_b1.php',
      'tab' => true,
    ),
    1 => 
    array (
      'module' => 'Eric_c1',
      'class' => 'Eric_c1',
      'path' => 'modules/Eric_c1/Eric_c1.php',
      'tab' => true,
    ),
    2 => 
    array (
      'module' => 'Eric_f1',
      'class' => 'Eric_f1',
      'path' => 'modules/Eric_f1/Eric_f1.php',
      'tab' => true,
    ),
    3 => 
    array (
      'module' => 'Eric_i1',
      'class' => 'Eric_i1',
      'path' => 'modules/Eric_i1/Eric_i1.php',
      'tab' => true,
    ),
    4 => 
    array (
      'module' => 'Eric_p1',
      'class' => 'Eric_p1',
      'path' => 'modules/Eric_p1/Eric_p1.php',
      'tab' => true,
    ),
    5 => 
    array (
      'module' => 'Eric_s1',
      'class' => 'Eric_s1',
      'path' => 'modules/Eric_s1/Eric_s1.php',
      'tab' => true,
    ),
  ),
  'layoutdefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Eric_b1.php',
      'to_module' => 'Eric_b1',
    ),
  ),
  'relationships' => 
  array (
    0 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/eric_b1_accountsMetaData.php',
    ),
    1 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/eric_b1_eric_f1MetaData.php',
    ),
    2 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/eric_b1_accounts_1MetaData.php',
    ),
  ),
  'image_dir' => '<basepath>/icons',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Eric_b1',
      'to' => 'modules/Eric_b1',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Eric_c1',
      'to' => 'modules/Eric_c1',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Eric_f1',
      'to' => 'modules/Eric_f1',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Eric_i1',
      'to' => 'modules/Eric_i1',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Eric_p1',
      'to' => 'modules/Eric_p1',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Eric_s1',
      'to' => 'modules/Eric_s1',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Eric_b1.php',
      'to_module' => 'Eric_b1',
      'language' => 'en_us',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Eric_f1.php',
      'to_module' => 'Eric_f1',
      'language' => 'en_us',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Eric_b1.php',
      'to_module' => 'Eric_b1',
      'language' => 'en_us',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Eric_b1.php',
      'to_module' => 'Eric_b1',
      'language' => 'en_us',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
  'vardefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Eric_b1.php',
      'to_module' => 'Eric_b1',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Eric_f1.php',
      'to_module' => 'Eric_f1',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Eric_b1.php',
      'to_module' => 'Eric_b1',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Eric_b1.php',
      'to_module' => 'Eric_b1',
    ),
  ),
  'layoutfields' => 
  array (
    0 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    1 => 
    array (
      'additional_fields' => 
      array (
        'Accounts' => 'eric_b1_accounts_1_name',
      ),
    ),
  ),
);