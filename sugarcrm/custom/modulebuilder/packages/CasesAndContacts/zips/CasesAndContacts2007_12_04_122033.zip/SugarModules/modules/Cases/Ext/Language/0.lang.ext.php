<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_THREADS_SUBPANEL_TITLE'] = 'Threads';



?>