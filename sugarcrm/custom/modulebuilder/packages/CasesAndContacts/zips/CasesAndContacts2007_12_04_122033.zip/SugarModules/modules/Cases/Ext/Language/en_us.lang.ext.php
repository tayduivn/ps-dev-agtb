<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_THREADS_SUBPANEL_TITLE'] = 'Threads';





$mod_strings['LBL_PROJECTS_SUBPANEL_TITLE'] = 'Projects';





$mod_strings['LBL_ITREQUESTS_SUBPANEL_TITLE'] = 'ITRequests';



?>