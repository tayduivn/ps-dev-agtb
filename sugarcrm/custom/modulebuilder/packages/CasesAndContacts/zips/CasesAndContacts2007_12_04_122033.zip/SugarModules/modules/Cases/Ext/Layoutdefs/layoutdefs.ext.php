<?php 
 //WARNING: The contents of this file are auto-generated

 

$layout_defs['Cases']['subpanel_setup']['threads'] =  array(
            'order' => 83,
            'module' => 'Threads',
            'sort_order' => 'asc',
            'sort_by' => 'date_modified',
            'get_subpanel_data' => 'threads',
            'add_subpanel_data' => 'thread_id',
            'subpanel_name' => 'default',
            'title_key' => 'LBL_THREADS_SUBPANEL_TITLE',
            'top_buttons' => array(
                array('widget_class' => 'SubPanelTopCreateButton'),
                array('widget_class' => 'SubPanelTopSelectButton'),
            ),
		);


 

$layout_defs['Cases']['subpanel_setup']['projects'] =  array(
    'order' => 50,
    'module' => 'Project',
    'sort_order' => 'desc',
    'sort_by' => 'project_id',
    'subpanel_name' => 'default',
	'refresh_page' => 1,
    'get_subpanel_data' => 'projects',
    'add_subpanel_data' => 'project_id',
    'title_key' => 'LBL_PROJECTS_SUBPANEL_TITLE',
    'top_buttons' => array(
        array('widget_class' => 'SubPanelTopSelectButton'),
	),
);


 

$layout_defs['Cases']['subpanel_setup']['itrequests'] =  array(
            'order' => 83,
            'module' => 'ITRequests',
            'sort_order' => 'asc',
            'sort_by' => 'date_modified',
            'get_subpanel_data' => 'itrequests',
            'add_subpanel_data' => 'itrequest_id',
            'subpanel_name' => 'default',
            'title_key' => 'LBL_ITREQUESTS_SUBPANEL_TITLE',
            'top_buttons' => array(
                array('widget_class' => 'SubPanelTopCreateButton'),
                array('widget_class' => 'SubPanelTopSelectButton'),
            ),
		);




//auto-generated file DO NOT EDIT
$layout_defs['Cases']['subpanel_setup']['contacts']['override_subpanel_name'] = 'Casedefault';




//auto-generated file DO NOT EDIT
$layout_defs['Cases']['subpanel_setup']['bugs']['override_subpanel_name'] = 'Casedefault';

?>