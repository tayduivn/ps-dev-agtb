<?php 
 //WARNING: The contents of this file are auto-generated


//BEGIN SADEK
$dictionary['Case']['fields']['threads'] =   array (
    'name' => 'threads',
    'type' => 'link',
    'relationship' => 'cases_threads',
    'module'=>'threads',
    'bean_name'=>'Threads',
    'source'=>'non-db',
    'vname'=>'LBL_THREADS',
);

$dictionary['Case']['relationships']['cases_threads'] = array(
    'lhs_module'=> 'Cases',
    'lhs_table'=> 'cases',
    'lhs_key' => 'id',
    
    'rhs_module'=> 'thread',
    'rhs_table'=> 'threads',
    'rhs_key' => 'id',

    'relationship_type'=>'many-to-many',
	'join_table'=> 'cases_threads',
	'join_key_lhs'=>'case_id',
	'join_key_rhs'=>'thread_id'
);
//END SADEK


//BEGIN CASES VARDEFS 
// adding project field
$dictionary['Case']['fields']['projects'] =   array (
    'name' => 'projects',
    'type' => 'link',
    'relationship' => 'projects_cases',
    'source'=>'non-db',
    'vname'=>'LBL_PROJECTS',
);
//END CASES VARDEFS


//BEGIN SADEK
$dictionary['Case']['fields']['itrequests'] =   array (
    'name' => 'itrequests',
    'type' => 'link',
    'relationship' => 'itrequests_cases',
    'module'=>'itrequests',
    'bean_name'=>'itrequests',
    'source'=>'non-db',
    'vname'=>'LBL_ITREQUESTS',
);

$dictionary['Case']['relationships']['itrequests_cases'] = array(
    'lhs_module'=> 'Cases',
    'lhs_table'=> 'cases',
    'lhs_key' => 'id',
    
    'rhs_module'=> 'itrequest',
    'rhs_table'=> 'itrequests',
    'rhs_key' => 'id',

    'relationship_type'=>'many-to-many',
	'join_table'=> 'itrequests_cases',
	'join_key_lhs'=>'case_id',
	'join_key_rhs'=>'itrequest_id'
);
//END SADEK


?>