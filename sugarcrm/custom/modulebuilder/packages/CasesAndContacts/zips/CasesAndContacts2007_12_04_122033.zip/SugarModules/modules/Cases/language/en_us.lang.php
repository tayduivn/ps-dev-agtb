<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

// 2005-03-04 18:06:56
// Module: Cases
// Language: en_us

// Added by Julian-- upgrade fix for bug #618
$mod_strings['LBL_PRIORITY_LEVEL'] = 'Priority Level';
// End added by Julian
$mod_strings['Sugar_Edition_c'] = 'Sugar Edition:';
$mod_strings['Category__c'] = 'Product Category:';
$mod_strings['Sugar_Version__c'] = 'Sugar Version:';
$mod_strings['Deployment_Option__c'] = 'Deployment Option:';
$mod_strings['PHP_Version__c'] = 'PHP Version:';
$mod_strings['Database_Version__c'] = 'Database Version:';
$mod_strings['Web_Server__c'] = 'Web Server:';
$mod_strings['Operating_System__c'] = 'Operating System:';
$mod_strings['Submitter_c'] = 'Portal Submitter:';
$mod_strings['Status_Summary_c'] = 'Status Summary:';
$mod_strings['Request_Type_c'] = 'Request Type:';
$mod_strings['Related_To_c'] = 'Related To:';
$mod_strings['Support_Service_Level_c'] = 'Support Service Level';
$mod_strings['Support_Service_Level_c_0'] = 'Support Service Level';
$mod_strings['Support_Service_Level_c_1'] = 'Support Service Level';
$mod_strings['Document_Resolution__c'] = 'Document Resolution?';
$mod_strings['Documentation_Location_c'] = 'Documentation Location';
$mod_strings['LBL_KEYWORD'] = 'Keyword:';


$mod_strings['presales_subcategory_c']='Pre-Sales Sub-Category';

$mod_strings['discuss_in_cometo_c']='Discuss In ComeTo?';