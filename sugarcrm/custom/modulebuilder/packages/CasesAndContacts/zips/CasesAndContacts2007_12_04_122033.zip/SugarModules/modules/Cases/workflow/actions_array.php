<?php
//Workflow Action Meta Data Arrays 
$action_meta_array = array ( 

'Cases3_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'request_type_c' => 'pre_sales_support', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

'Cases8_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'created_notify_sent_c' => 'bool_true', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

'Cases9_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'created_notify_sent_c' => 'bool_true', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

'Cases11_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'assigned_user_id' => 'd624760c-78cb-1a37-3172-421f56e40d98', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

); 

 

?>