<?php
//Workflow Alert Meta Data Arrays 
$alert_meta_array = array ( 

'Cases0_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '61b37808-32ec-e678-0de6-44163ac3e3a1', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases0_alert1' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '4d3fabcd-f98f-64b4-ec4e-42828344f2e4', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases1_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '8984c5a0-8229-ef61-9908-42518864b933', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_1' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '61b37808-32ec-e678-0de6-44163ac3e3a1', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_2' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '1f67ea67-aece-0cf5-a6ec-444045f895d2', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_3' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '1a06f6e0-9afc-50d3-8c58-433835ff0552', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases2_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '4d3fabcd-f98f-64b4-ec4e-42828344f2e4', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases4_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'da40c785-eff8-37bc-df67-414f1cf6857f', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_1' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'a29b5e5e-d56e-de5c-d0b2-4609a9b14c8d', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_2' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'c23afcdb-5b49-0b5b-f4c8-465c87d7391c', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_3' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'ab83f24c-599d-2062-34ca-468005f5c8ff', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_4' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'bb8de9e0-9dd4-ef1a-3117-46dd8b957904', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases5_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'a29b5e5e-d56e-de5c-d0b2-4609a9b14c8d', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

	 'user_1' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'bb8de9e0-9dd4-ef1a-3117-46dd8b957904', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases6_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'current_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

	 'user_1' => array ( 

		 'user_type' => 'current_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'created_by', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user1', 
	 ), 

), 

'Cases7_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => 'contacts', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases7_alert1' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '4d3fabcd-f98f-64b4-ec4e-42828344f2e4', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases8_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '4d3fabcd-f98f-64b4-ec4e-42828344f2e4', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases8_alert1' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => 'contacts', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases9_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '4d3fabcd-f98f-64b4-ec4e-42828344f2e4', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases9_alert1' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => 'contacts', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases10_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'cc', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'da40c785-eff8-37bc-df67-414f1cf6857f', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases12_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => '8984c5a0-8229-ef61-9908-42518864b933', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

'Cases13_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'specific_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'eebff7f0-fcd1-6421-ec14-4735112a155f', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => '', 
	 ), 

), 

); 

 

?>