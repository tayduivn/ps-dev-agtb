<?php
//Workflow Triggers Meta Data Arrays 
$trigger_meta_array = array ( 

'trigger_1' => 

array ( 

	 'base' => array ( 

		 'lhs_field' => 'Support_Service_Level_c', 
		 'lhs_type' => 'rel_module', 
		 'lhs_module' => 'Accounts', 
		 'operator' => 'Equals', 
		 'rhs_value' => 'premium', 
	 ), 

), 

'trigger_12' => 

array ( 

	 'base' => array ( 

		 'lhs_field' => 'name', 
		 'lhs_type' => 'rel_module', 
		 'lhs_module' => 'Accounts', 
		 'operator' => 'Equals', 
		 'rhs_value' => 'Graphics & Motion', 
	 ), 

), 

); 

 

?>