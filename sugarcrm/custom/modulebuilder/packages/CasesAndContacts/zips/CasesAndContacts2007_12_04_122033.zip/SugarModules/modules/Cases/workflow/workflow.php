<?php

include_once("include/workflow/alert_utils.php");
include_once("include/workflow/action_utils.php");
include_once("include/workflow/time_utils.php");
include_once("include/workflow/trigger_utils.php");
//BEGIN WFLOW PLUGINS
include_once("include/workflow/custom_utils.php");
//END WFLOW PLUGINS
	class Cases_workflow {
	function process_wflow_triggers(& $focus){
		include("custom/modules/Cases/workflow/triggers_array.php");
		include("custom/modules/Cases/workflow/alerts_array.php");
		include("custom/modules/Cases/workflow/actions_array.php");
		include("custom/modules/Cases/workflow/plugins_array.php");
		if(empty($focus->fetched_row['id'])){ 
 
 if( ($focus->priority_level ==  'P1 System Down')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->request_type_c ==  'technical_support')	 ){ 
	 

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "58cc1b06-beb6-7854-6f46-440683a7d3e9"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases0_alert0'], $alertshell_array, false); 
 	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "58cc1b06-beb6-7854-6f46-440683a7d3e9"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases0_alert1'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id'])){ 
 	 $primary_array = array();
	 $primary_array = check_rel_filter($focus, $primary_array, 'account', $trigger_meta_array['trigger_1'], 'any'); 

 if(($primary_array['results']==true)
){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->priority_level ==  'P1 System Down')	 ){ 
	 

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "58cc1b06-beb6-7854-6f46-440683a7d3e9"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases1_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( ( ( isset($focus->status) && $focus->fetched_row['status'] != $focus->status) || ( $focus->fetched_row['status'] == null && !isset($focus->status) ) )  ||  (  isset($focus->status) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->status 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->Support_Service_Level_c ==  'Premium Support')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( ($focus->status ==  'New')	 ){ 
	 

	 //Secondary Trigger number #3
	 if( ($focus->priority_level ==  'P1 System Down')	 ){ 
	 

	 $time_array['time_int'] = '900'; 

	 $time_array['parameters'] = $focus->status; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'b67b3b55-ab89-f511-78f6-44069f6ff464'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && 
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
					 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "b47a42b2-c8c7-09cd-bcc8-44071b4dd5fe"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases2_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 } 

 	 else{ 

		 check_for_schedule($focus, $workflow_id, $time_array); 

 	 } 

  

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 // End Secondary Trigger number #3
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


 if( ( !($focus->fetched_row['assigned_user_id'] ==  '8402a329-9ff6-154f-f58f-446375173cef' )) && 
 ($focus->assigned_user_id ==  '8402a329-9ff6-154f-f58f-446375173cef')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 unset($alertshell_array); 
	 process_workflow_actions($focus, $action_meta_array['Cases3_action0']); 
  

	 //End Frame Secondary 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


 if( ( !($focus->fetched_row['request_type_c'] ==  'pre_sales_support' )) && 
 ($focus->request_type_c ==  'pre_sales_support')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "333a0899-82a9-765e-32b6-4457c9b45994"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases4_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


 if( (  ( !($focus->fetched_row['status'] ==  'New' )) && 
 ($focus->status ==  'New') )  ||  (  ($focus->status ==  'New') && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->request_type_c ==  'pre_sales_support')	 ){ 
	 

	 $trigger_time_count = '1'; 

 	 $time_array['time_int'] = '86400'; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '5e345d00-e7c1-12e9-dbf2-4464a0bee3ff'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && 
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
					 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "4a38ffa1-618c-9fcf-97a1-4404ddd9ac53"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases5_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 } 

 	 else{ 

		 check_for_schedule($focus, $workflow_id, $time_array); 

 	 } 

  

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

if(isset($focus->fetched_row['id']) && $focus->fetched_row['id']!=""){ 
 
 if($focus->fetched_row['status'] != $focus->status){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->request_type_c ==  'pre_sales_support')	 ){ 
	 

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "365f03d8-114b-87b8-01fe-44ecf9dce386"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases6_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(isset($focus->fetched_row['id']) && $focus->fetched_row['id']!=""){ 
 
 if($focus->fetched_row['status'] != $focus->status){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->request_type_c ==  'technical_support')	 ){ 
	 

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "4a8e6995-ad64-461b-cb4f-4509efffd912"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases7_alert0'], $alertshell_array, false); 
 	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "4a8e6995-ad64-461b-cb4f-4509efffd912"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases7_alert1'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( ( ( isset($focus->date_entered) && $focus->fetched_row['date_entered'] != $focus->date_entered) || ( $focus->fetched_row['date_entered'] == null && !isset($focus->date_entered) ) )  ||  (  isset($focus->date_entered) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->date_entered 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (
 	 ( 
 		$focus->created_notify_sent_c ==  'false'|| 
 		$focus->created_notify_sent_c ==  'off'||  
 		$focus->created_notify_sent_c ==  '0'
 	 )  
)	 ){ 
	 

	 //Secondary Trigger number #2
	 if( ($focus->request_type_c ==  'technical_support')	 ){ 
	 

	 //Secondary Trigger number #3
	 if( ($focus->created_by !=  '730d4985-5c03-3b38-ea75-43f65920c70a')	 ){ 
	 

	 $time_array['time_int'] = '300'; 

	 $time_array['parameters'] = $focus->date_entered; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'dc190da5-f9ad-f049-8b21-450e025e943f'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && 
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
					 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "957c7da1-13be-d132-c88c-4509f138377d"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases8_alert0'], $alertshell_array, false); 
 	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "957c7da1-13be-d132-c88c-4509f138377d"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases8_alert1'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 process_workflow_actions($focus, $action_meta_array['Cases8_action0']); 
 	 } 

 	 else{ 

		 check_for_schedule($focus, $workflow_id, $time_array); 

 	 } 

  

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 // End Secondary Trigger number #3
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


 if( ( ( isset($focus->date_entered) && $focus->fetched_row['date_entered'] != $focus->date_entered) || ( $focus->fetched_row['date_entered'] == null && !isset($focus->date_entered) ) )  ||  (  isset($focus->date_entered) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->date_entered 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->request_type_c ==  'technical_support')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( ($focus->created_by ==  '730d4985-5c03-3b38-ea75-43f65920c70a')	 ){ 
	 

	 //Secondary Trigger number #3
	 if( (
 	 ( 
 		$focus->created_notify_sent_c ==  'false'|| 
 		$focus->created_notify_sent_c ==  'off'||  
 		$focus->created_notify_sent_c ==  '0'
 	 )  
)	 ){ 
	 

	 $time_array['time_int'] = '60'; 

	 $time_array['parameters'] = $focus->date_entered; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '23767921-f0f3-8e14-44fc-4511935970f3'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && 
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
					 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "957c7da1-13be-d132-c88c-4509f138377d"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases9_alert0'], $alertshell_array, false); 
 	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "957c7da1-13be-d132-c88c-4509f138377d"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases9_alert1'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 process_workflow_actions($focus, $action_meta_array['Cases9_action0']); 
 	 } 

 	 else{ 

		 check_for_schedule($focus, $workflow_id, $time_array); 

 	 } 

  

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 // End Secondary Trigger number #3
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

if(isset($focus->fetched_row['id']) && $focus->fetched_row['id']!=""){ 
 
 if( (  ( !(( in_array( 'Assigned',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) || 
( in_array( 'New',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) || 
( in_array( 'Pending Input',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) || 
( in_array( 'Pending Internal Input',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) )) && 
 (( in_array( 'Assigned',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'New',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Pending Input',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Pending Internal Input',explode(',',str_replace('^,^', ',', $focus->status)) ) )) )  ||  (  (( in_array( 'Assigned',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'New',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Pending Input',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Pending Internal Input',explode(',',str_replace('^,^', ',', $focus->status)) ) )) && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (  ( !(( in_array( '25e1d3b4-1276-ea94-6179-452e69dfb366',explode(',',str_replace('^,^', ',', $focus->fetched_row['created_by'])) ) ) || 
( in_array( '88280e20-7233-122e-e197-463f65208d74',explode(',',str_replace('^,^', ',', $focus->fetched_row['created_by'])) ) ) || 
( in_array( 'da40c785-eff8-37bc-df67-414f1cf6857f',explode(',',str_replace('^,^', ',', $focus->fetched_row['created_by'])) ) ) || 
( in_array( '5ee57af9-d49d-32c5-56bc-461c492ace39',explode(',',str_replace('^,^', ',', $focus->fetched_row['created_by'])) ) ) || 
( in_array( 'aaf768e5-0479-4d4c-a477-44a9656757dd',explode(',',str_replace('^,^', ',', $focus->fetched_row['created_by'])) ) ) || 
( in_array( 'a6764d0d-927e-0828-b5a5-44e345a5be4e',explode(',',str_replace('^,^', ',', $focus->fetched_row['created_by'])) ) ) )) && 
 (( in_array( '25e1d3b4-1276-ea94-6179-452e69dfb366',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( '88280e20-7233-122e-e197-463f65208d74',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( 'da40c785-eff8-37bc-df67-414f1cf6857f',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( '5ee57af9-d49d-32c5-56bc-461c492ace39',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( 'aaf768e5-0479-4d4c-a477-44a9656757dd',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( 'a6764d0d-927e-0828-b5a5-44e345a5be4e',explode(',',str_replace('^,^', ',', $focus->created_by)) ) )) )  ||  (  (( in_array( '25e1d3b4-1276-ea94-6179-452e69dfb366',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( '88280e20-7233-122e-e197-463f65208d74',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( 'da40c785-eff8-37bc-df67-414f1cf6857f',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( '5ee57af9-d49d-32c5-56bc-461c492ace39',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( 'aaf768e5-0479-4d4c-a477-44a9656757dd',explode(',',str_replace('^,^', ',', $focus->created_by)) ) ) || 
( in_array( 'a6764d0d-927e-0828-b5a5-44e345a5be4e',explode(',',str_replace('^,^', ',', $focus->created_by)) ) )) && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) 	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (  ( !($focus->fetched_row['request_type_c'] ==  'pre_sales_support' )) && 
 ($focus->request_type_c ==  'pre_sales_support') )  ||  (  ($focus->request_type_c ==  'pre_sales_support') && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) 	 ){ 
	 

	 $trigger_time_count = '4'; 

 	 $time_array['time_int'] = '172800'; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'a93e6295-bbb5-62f1-2c10-46606dae7bf1'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && 
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
					 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "1e4335fa-91ea-27b9-0043-466071fd0922"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases10_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 } 

 	 else{ 

		 check_for_schedule($focus, $workflow_id, $time_array); 

 	 } 

  

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( ($focus->request_type_c ==  'pre_sales_support')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( ($focus->presales_subcategory_c ==  'IT Support')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( ($focus->assigned_user_id ==  '8402a329-9ff6-154f-f58f-446375173cef')	 ){ 
	 

	 //Secondary Trigger number #3
	 if( ($focus->status ==  'New')	 ){ 
	 

	 unset($alertshell_array); 
	 process_workflow_actions($focus, $action_meta_array['Cases11_action0']); 
  

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 // End Secondary Trigger number #3
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

if(empty($focus->fetched_row['id'])){ 
 	 $primary_array = array();
	 $primary_array = check_rel_filter($focus, $primary_array, 'account', $trigger_meta_array['trigger_12'], 'any'); 

 if(($primary_array['results']==true)
){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "There&#039;s a new case for a Verio customer.  Check it out!"; 

	 $alertshell_array['source_type'] = "Normal Message"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases12_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( ( !(( in_array( 'Closed Defect',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) || 
( in_array( 'Closed Feature',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) || 
( in_array( 'Closed No Response',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) || 
( in_array( 'Closed',explode(',',str_replace('^,^', ',', $focus->fetched_row['status'])) ) ) )) && 
 (( in_array( 'Closed Defect',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Closed Feature',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Closed No Response',explode(',',str_replace('^,^', ',', $focus->status)) ) ) || 
( in_array( 'Closed',explode(',',str_replace('^,^', ',', $focus->status)) ) ))){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->request_type_c) && $focus->request_type_c ==  'technical_support')	 ){ 
	 

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "9e9902c7-88a1-7a12-063e-473ceadeb63f"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Cases13_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


	//end function process_wflow_triggers
	}
	
	//end class
	}

?>