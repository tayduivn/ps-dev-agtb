<?php 
 //WARNING: The contents of this file are auto-generated


// Creation date: 2006-05-05 22:35:09
// Module: contacts
// Language: en_us

$mod_strings['LBL_MAP'] = 'Get Map';
$mod_strings['LBL_DIRECTIONS'] = 'Get Directions';

?>