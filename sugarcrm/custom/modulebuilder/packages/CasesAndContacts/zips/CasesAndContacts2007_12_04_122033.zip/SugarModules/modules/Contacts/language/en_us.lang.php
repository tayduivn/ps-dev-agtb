<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

// 2005-02-24 15:19:00
// Module: Contacts
// Language: en_us

$mod_strings['LBL_TECHNICAL_PROFICIENCY_'] = 'Technical Proficiency';
$mod_strings['LBL_SYNC_CONTACT'] = 'Sync to Contact Manager:';

$mod_strings['LNK_CONTACT_REPORTS'] = "Contact Reports";
$mod_strings['Primary_Business_Contact__c'] = 'Primary Business Contact:';
$mod_strings['Support_Authorized_Contact__c'] = 'Support Authorized Contact:';
$mod_strings['Student_c'] = 'Student';
$mod_strings['Final_Exam_Graded_By_c'] = 'Final Exam Graded By';


$mod_strings['Billing_Contact__c']='Billing Contact:';