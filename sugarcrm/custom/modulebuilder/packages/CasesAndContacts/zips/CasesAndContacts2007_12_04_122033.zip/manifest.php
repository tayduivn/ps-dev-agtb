	<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	$manifest = array (
		 'acceptable_sugar_versions' => 
		  array (
	     	'5.0.0'
		  ),
		  'acceptable_sugar_flavors' =>
		  array(
		  	'ENT'
		  ),
		  'readme'=>'',
		  'key'=>'',
		  'author' => 'Jason Nassi',
		  'description' => 'Doing module development on a test system that will be linked with the Cases and Contact modules of Internal Sugar.  Need snapshots of the custom field definitions.',
		  'icon' => '',
		  'is_uninstallable' => true,
		  'name' => 'CasesAndContacts',
		  'published_date' => '2007-12-04 20:20:32',
		  'type' => 'module',
		  'version' => '1196799632',
		  'remove_tables' => 'prompt',
		  );
$installdefs = array (
  'id' => 'CasesAndContacts',
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/include/language/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Cases/language/en_us.lang.php',
      'to_module' => 'Cases',
      'language' => 'en_us',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Contacts/language/en_us.lang.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
  ),
  'custom_fields' => 
  array (
    '' => 
    array (
      'id' => 'Contactsbilling_contact_c',
      'name' => 'billing_contact_c',
      'label' => 'Billing_Contact__c',
      'help' => NULL,
      'module' => 'Contacts',
      'data_type' => 'bool',
      'max_size' => '50',
      'required_option' => 'optional',
      'default_value' => NULL,
      'date_modified' => '2007-01-30 23:48:25',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
      'duplicate_merge' => '0',
      'type' => 'bool',
      'require_option' => '0',
      'reportable' => '1',
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Cases/metadata/SearchFields.php',
      'to' => 'custom/modules/Cases/metadata/SearchFields.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Cases/metadata/SearchFields.php',
      'to' => 'custom/working/modules/Cases/metadata/SearchFields.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/Cases/metadata/listviewdefs.php',
      'to' => 'custom/modules/Cases/metadata/listviewdefs.php',
    ),
  ),
);