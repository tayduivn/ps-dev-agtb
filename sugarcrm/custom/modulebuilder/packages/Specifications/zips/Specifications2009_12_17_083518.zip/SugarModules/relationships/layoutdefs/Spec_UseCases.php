<?php
// created: 2009-11-18 15:33:24
$layout_defs["Spec_UseCases"]["subpanel_setup"]["spec_usecases_bugs"] = array (
  'order' => 100,
  'module' => 'Bugs',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SPEC_USECASES_BUGS_FROM_BUGS_TITLE',
  'get_subpanel_data' => 'spec_usecases_bugs',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2009-12-17 08:35:18
$layout_defs["Spec_UseCases"]["subpanel_setup"]["spec_usecases_bugs"] = array (
  'order' => 100,
  'module' => 'Bugs',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SPEC_USECASES_BUGS_FROM_BUGS_TITLE',
  'get_subpanel_data' => 'spec_usecases_bugs',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
