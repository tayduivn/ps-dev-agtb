<?php
// created: 2009-11-18 15:33:24
$dictionary["Spec_UseCases"]["fields"]["spec_usecases_bugs"] = array (
  'name' => 'spec_usecases_bugs',
  'type' => 'link',
  'relationship' => 'spec_usecases_bugs',
  'source' => 'non-db',
  'vname' => 'LBL_SPEC_USECASES_BUGS_FROM_BUGS_TITLE',
);
?>
<?php
// created: 2009-12-17 08:35:18
$dictionary["Spec_UseCases"]["fields"]["spec_usecases_bugs"] = array (
  'name' => 'spec_usecases_bugs',
  'type' => 'link',
  'relationship' => 'spec_usecases_bugs',
  'source' => 'non-db',
  'vname' => 'LBL_SPEC_USECASES_BUGS_FROM_BUGS_TITLE',
);
?>
