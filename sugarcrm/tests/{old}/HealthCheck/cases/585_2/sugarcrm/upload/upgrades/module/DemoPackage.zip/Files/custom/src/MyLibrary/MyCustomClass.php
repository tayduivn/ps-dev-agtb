<?php

namespace Sugarcrm\Sugarcrm\custom\MyLibrary;

use \Sugarcrm\Sugarcrm\Logger\Factory;

class MyCustomClass
{
    public function MyCustomMethod($message = 'relax')
    {
        $logger = Factory::getLogger('default');
        $logger->info('MyCustomClass says' . "'{$message}'");
    }
}
