<?php

$manifest = array(
    'acceptable_sugar_flavors' => array('PRO','ENT','ULT'),
    'acceptable_sugar_versions' => array(
        'exact_matches' => array(),
        'regex_matches' => array('(.*?)\\.(.*?)\\.(.*?)$'),
    ),
    'author' => 'SugarCRM',
    'description' => 'Copies my files to custom/src/',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => 'Example File Installer',
    'published_date' => '2018-06-29 00:00:00',
    'type' => 'module',
    'version' => '1530305622',
);

$installdefs = array(
    'id' => 'package_1530305622',
    'copy' => array(
        0 => array(
            'from' => '<basepath>/Files/custom/src/MyLibrary/MyCustomClass.php',
            'to' => 'custom/src/MyLibrary/MyCustomClass.php',
        ),
    ),
);
